package com.app.services;

import com.app.pojos.Admin;

public interface AdminService {
	
	
	Admin validate(String userid,String pwd);
	
	
	void updateAdmin(Admin admin);
	
	
}
