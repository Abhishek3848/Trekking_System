package com.app.p27_orderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P27OrderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
