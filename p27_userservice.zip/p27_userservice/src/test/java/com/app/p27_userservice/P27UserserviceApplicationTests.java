package com.app.p27_userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P27UserserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
