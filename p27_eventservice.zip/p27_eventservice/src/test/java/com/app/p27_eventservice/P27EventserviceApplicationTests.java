package com.app.p27_eventservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P27EventserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
